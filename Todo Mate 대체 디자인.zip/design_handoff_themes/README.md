# Handoff: 할 일 앱 테마 7종

## Overview
개인용 할 일 웹앱(“나의 할 일”)에 **사용자가 고르는 테마 7개**를 추가한다. 화면 구조(홈: 프로필 → 월간 달력 → 오늘 할 일 → 하단 탭바)는 그대로 두고, 테마마다 **색 · 글꼴 · 부품 모양 · 장식 레이어**만 바꾼다.
기존 앱의 부품 목록과 현재 값은 `DESIGN.md`(앱 측 문서)에 있다. 이 README는 그 목록의 각 항목을 테마별로 어떻게 바꾸는지 정의한다.

## About the Design Files
이 폴더의 HTML은 **디자인 레퍼런스(프로토타입)** 이다. 그대로 배포할 코드가 아니다. 앱의 기존 환경(프레임워크, 컴포넌트, CSS 방식)에 맞춰 **다시 구현**한다.
- `테마 제안.dc.html`: 브라우저로 바로 열린다(같은 폴더의 `support.js` 필요). 7개 테마의 홈 화면이 나란히 보이고, 체크 · 날짜 선택 · 카테고리 + 추가가 동작한다.
- **값의 원본**: 이 파일 아래쪽 `<script>`의 `const D = {...}`(기본값)와 `const THEMES = [...]`(테마별 덮어쓰기)에 있다. 그 뒤의 `THEMES[5] = ...`, `Object.assign(THEMES[5|6], ...)`가 최종 덮어쓰기다. 이 README의 숫자와 다르면 **파일이 우선**이다.

## Fidelity
**High-fidelity.** 색 · 글꼴 · 크기 · 둥근 정도 · 그림자는 최종값이다. 폭 390px 모바일 기준이다.

---

## 구현 구조 (권장)
1. **테마 토큰**: 테마마다 아래 키를 가진 객체(또는 CSS 변수 묶음)를 만들고, 루트에 `data-theme="matcha"` 같은 속성으로 전환한다. 키 목록은 파일의 `D` 객체와 같다.
2. **모양 변형(variant)**: 색만으로 안 되는 부품은 테마별 변형 컴포넌트로 만든다. 대상은 달력 마크, 상단 아이콘, 진행 표시, 탭바, 카테고리 칩이다.
3. **장식 레이어**: 테마별 배경 스티커와 일러스트는 내용 뒤(`z-index` 0, `pointer-events:none`)의 별도 레이어에 둔다. 내용 레이어는 `z-index:1`이다.
4. 설정 → “테마 설정”(현재 ‘준비 중’)에서 7개 중 하나를 고르고 `localStorage`에 저장한다.

### 토큰 키 (모든 테마 공통)
| 그룹 | 키 |
|---|---|
| 바탕 | `bg`(그라데이션 가능), `font`, `ink`(기본 글자), `sub`(흐린 글자), `ls`(자간) |
| 상단 | `statusBg`, `statusInk`, `topBg`, `topBorder`, `btnW/H`, `btnBg`, `btnBorder`, `btnColor`, `btnShadow`, `btnRad` |
| 프로필 | `avatarBg/Border/Shadow/Rad`, `nameFont/Size/Weight`, `bioFont/Size/Color`, `nameAlign`, `textShadow` |
| 달력 카드 | `cardBg/Border/Rad/Shadow`, `calHeadBg/Border/Pad`, `headRad`, `monthFont/Size/Weight/Color/Shadow`, `arrowColor`, `pillToday*`, `wdColor`, `sunColor`, `satColor`, `numColor`, `numFont` |
| 달력 마크 | `mRad`, `mClip`, `mBorderW`, `mEmpty`/`mPart`/`mFull`(각 `{bg,border,fg,shadow}`), `mCount`, `doneGlyph`, `selBg`, `selFg`, (아이폰만) `heat[4]` |
| 오늘 | `labelColor/Font/Size`, `dateFont/Size/Weight/Color`, `progTrack/Fill/H/Border/Rad/Shadow`, `progSuffix`(" 완료" 또는 "") |
| 카테고리 · 할 일 | `catRad/Border/Shadow/Font/Size/TextShadow/PadL/PadR/DotW`, `plusSize`, `cats[4]`(`{dot,bg,fg,plusBg,plusFg,box,on}`), `itemsBg/Border/Rad`, `itemPad`, `itemLine`, `itemFont/Size`, `boxRad`, `boxBorderW`, `boxEmpty`, `boxEmptyBg`, `boxDoneBorder`, `itemColor`, `doneColor` |
| 탭바 | `tabBg/Border/Active/Inactive/ActiveBg/Font` |

> **카테고리 색 주의:** 앱은 사용자가 고른 카테고리 색을 그대로 쓴다(DESIGN.md 2장). 시안의 `cats[4]`는 기본 4개 카테고리(학교 · 취업준비 · 운동 · 개인)의 예시다. 실제 구현에서는 테마마다 **20색 팔레트를 그 테마 톤으로 바꾼 목록**을 두고, 칩 바탕은 그 색의 연한 버전으로 계산하기를 권장한다. 시리얼과 아이폰은 칩 바탕이 진한 단색이나 유광이다.

---

## 테마별 명세

### 1a 기본 · 맑은 블루 (현재 앱 기준)
- 바탕 `#f3f6fb`, 카드 `#fff` r24, 그림자 `0 1px 2px rgba(31,42,58,.04),0 10px 24px -14px rgba(31,42,58,.16)`
- 글자 `#1f2a3a` / 흐림 `#6b7a90`, 대표색 `#3b6ea8`, Pretendard
- 달력 마크: **클로버**(28px, `clip-path:path()`로 원 4개 합집합). 비어 있음 `#e6ecf5`, 진행 중 `#c4d5ee`(남은 개수), 완료 `#6d9be8` + 흰 ✓
- 진행 바 8px `#e2e8f1` / `#3b6ea8`, 텍스트 “2 / 5 완료”

### 1b 말차코어
- 바탕 **미색 단색** `#f5f2e8`(무늬 없음), 카드 `#fffdf7`, 글자 `#1d2e1b`
- 달력 마크 **원형**: `#eceee2` → 진행 `#c8d2a6` → 완료 `#1d2e1b` + 라임 ✓ `#c9e05a`. 선택일 `#1d2e1b`/`#c9e05a`
- “오늘” 버튼 `#a9c632` 바탕 / `#1d2e1b`
- 카테고리 칩 **단색**: 학교 `#1d2e1b`/`#c9e05a`, 취업 `#dfe7cc`/`#3d5427`, 운동 `#ecf3c6`/`#4c5c12`, 개인 `#f1e6cc`/`#7a5c26`
- 장식: 달력 카드 왼쪽 위에 연두색 마스킹테이프 한 장(80×20, −5°)
- 탭바 `rgba(255,253,247,.95)`, 선택 탭 아이콘 뒤 `#dfe5cc` 알약

### 1c 시리얼 박스
- 바탕 `#fbefd9`, 남색 `#1b2340`, 빨강 `#e2412b`, 노랑 `#f7b928`, 파랑 `#2b5fb4`
- 글꼴: 로고 **Lilita One**, 한글 제목 · 칩 · 탭 **Jua(주아)**, 본문 Pretendard. 전체 자간 `.035em`
- 상태바 + 상단바가 파란 띠(`#2b5fb4`). 왼쪽에 **TODOLIST** 로고(글자마다 크림/노랑 번갈아, ±4~7° 기울임, 그림자 `2px 2px 0 #e2412b, 4px 4px 0 #1b2340`). 아래에 빨강 6px + 노랑 6px 줄무늬
- 모든 카드 · 칩 · 버튼: 테두리 2.5~3px `#1b2340` + **오프셋 그림자** `3~6px 3~6px 0 #1b2340`
- 달력 머리줄 빨간 띠, 달력 마크 = **시리얼 링(O)**: 5px 테두리 원. 비어 있음 `#f1dfb8`, 진행 `#f7b928`, 완료 빨강 채움 + 남색 테두리 + ✓
- 진행 바 18px, 빨강 사선 줄무늬, 테두리 2.5px, 텍스트 **“3 / 5”**(‘완료’ 없음)
- 장식: 프로필 오른쪽 노란 **별 배지** “NEVER / GIVE UP!”(24각 다각형, −10°). 오른쪽 아래 **작은 무지개**(지름 170, 빨/노/파/크림 동심원). 그 위 **TUTU 마스코트 원형 스티커**(112px, 흰 바탕, 3px 남색 테두리, 오프셋 그림자). “오늘” 옆에 시리얼 링 작은 그림
- 탭바 남색 `#1b2340`, 선택 `#f7b928`

### 1d 아이폰 2007
- 바탕 **무늬 없는 은회색** `linear-gradient(#e4e9ef,#d3dae3)`. 글꼴 Helvetica Neue Bold / Apple SD 고딕
- 상태바 검정. 상단바 유광 `linear-gradient(#b3c0d1,#8197b4 50%,#6e86a7 51%,#5c779c)`, 가운데 제목 **“Home”**. 아이콘 버튼은 유광 직사각형(42×32, r7)
- 글자에 흰 엠보스 `text-shadow:0 1px 0 rgba(255,255,255,.8)`
- 달력 카드 r10, 1px `#8e98a6`. 머리줄은 **얇게**(padding 7px 12px, 월 16px), 회색 유광 그라데이션
- 달력 마크 = **젤리 버튼**. **남은 일이 많을수록 파랑이 진해짐**(`heat` 4단계: 1개 → 4개 이상, 마지막 단계는 짙은 남색 + 흰 숫자). 다 끝낸 날은 **은색 유광 + 파란 ✓**
- 카테고리 = **유광 알약**(색별 2단 그라데이션, 흰 글자 + 위 그림자). 할 일 줄은 **배경 없음**
- 탭바: 검은 유광 `linear-gradient(#5c5c5c 0,#2e2e2e 1px,#1c1c1c 50%,#000 51%)`, **꽉 찬 30px 아이콘**, 영문 라벨 **HOME / PLAN / TIMER / PROFILE**(10.5px bold). 선택 탭은 반투명 흰 유광 타일 + **흰 빛 번짐**(`drop-shadow(0 0 5px rgba(255,255,255,.95))`)

### 1e 다크 · 부드러운 밤 (확정, 그대로 구현)
- 바탕 `#1d1e22`, 카드 `#26272c` + 1px `#2e2f35`, 그림자 없음
- 글자 미색 `#e9e7e2`, 흐림 `#9a9aa0`, 포인트 `#8fb2ec`
- 달력 마크 둥근 사각(r11): `#303137` → 진행 `#3a4760` → 완료 `#8fb2ec` + 진한 ✓. 선택일 `#e9e7e2`/`#1d1e22`
- 카테고리: 색 14% 투명 바탕 + 채도 낮춘 파스텔 글자
- 장식: 위쪽 아주 옅은 푸른 빛(`radial-gradient` 13%)

### 1f 소녀 · 위시코어
- 바탕 **핑크 → 흰색 → 초록 그라데이션** `linear-gradient(165deg,#fde6ee,#fdfbfb 48%,#e3f2dc)`. 물방울 무늬는 **상태바 + 상단바에만**(`#d6e8f8` 1.8px, 16px 간격), 상단바 아래 점선
- 글꼴: 제목 · 날짜 · “오늘” · 칩 **Gaegu**, 할 일 **미생체**(SDMiSaeng, 21px), 본문 고운돋움. 미생체 웹폰트:
  `@font-face{font-family:'SDMiSaeng';src:url('https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_two@1.0/SDMiSaeng.woff') format('woff')}`
- 상단 아이콘: **테두리 원 없음**. 알림 = 하트 붙은 편지, 친구 = 고양이 얼굴 두 개
- 프로필: 하늘색 **헤일로**(48×13 타원, 3px `#a9cdee`, 빛 번짐) + 흰 **날개**(깃털 3장, 1.5~2px `#a9cdee` 테두리). 이름과 소개는 사진 **아래쪽 선에 맞춤**
- 달력 카드: 위 가장자리에 흰 레이스(스캘럽), 왼쪽 위에 분홍 **리본**(양쪽 날개 + 둥근 매듭 + 꼬리 2개)
- 달력 마크 = **나루토마끼**(30px, 32각 톱니 원 2겹). 비어 있음 `#f2f7fb`, 할 일 있음 `#e6f1fb` + 남은 개수, 완료 흰 원 + **분홍 소용돌이**(`#f28cb1`, 2px, 반경 9px 이내)
- “오늘” 옆 네잎클로버, 진행 표시 = **얇은 스티치 리본끈**(10px, 분홍 리본 위 흰 점선 바느질), 텍스트 “3 / 5”
- 카테고리 = **파스텔 반창고**(r999, 가운데 흰 패드 52%×70%, 양 끝 작은 구멍 무늬). 왼쪽 점 없음, +는 배경 없이 작고 흐리게. 칩마다 **−2° / +1.6° / −1.4° / +2.2°** 번갈아 기울임
- 할 일 사이 구분선 없음. 체크 = 원 + ★
- 장식 레이어: 흐린 별, 크레파스 소용돌이, 해파리, 클로버, 핑크 · 초록 번짐
- 탭바: 홈 = 집 + **물결 날개**, 플래너 = 초록 소용돌이, 타이머 = 흐린 토마토, 개인정보 = 헤드폰 + 작은 ♪

### 1g 우주 · 달을 향해
- 바탕 `radial-gradient(circle at 85% 8%,#1d2c47 0,#0d1420 50%)` + 희미한 별 44개(1.5~2.5px, 투명도 .25~.75)
- 글꼴 Noto Sans KR(이름 21px / 소개 12.5px도 같은 글꼴), 숫자 · 월 Space Mono
- 프로필 오른쪽 **달**(66px SVG): **선택한 날짜의 실제 달 위상**을 계산한다. 기준 삭(신월) 2000-01-06 18:14 UTC, 삭망월 29.530588853일. 밝은 쪽 = 반원 + 반타원(rx = 33·|cos 2πp|) 경로. 아래 영문 위상 이름(NEW MOON … WANING CRESCENT)
- 달 왼쪽 위 **북두칠성**(7점 + 선, 투명도 .45, 18° 기울임), 달과 겹치지 않게 띄움
- 달력 마크 = **그날 끝낸 비율만큼 차오르는 달**(inset 그림자로 밝은 부분 표현, 다 끝내면 보름달 + 빛 번짐). 숫자 없음, 범례 없음
- 진행 바 4px 빛나는 궤적, 텍스트 “3 / 5”. 체크 ✦

---

## Interactions & Behavior
- 날짜 칸 클릭 → 선택일 변경, 아래 목록 · 진행 표시 · (우주) 달 위상 갱신
- 할 일 체크 토글: 체크 원 채움, 글자 회색 + 가운데 줄. 달력 마크도 즉시 바뀜(transition .3s)
- 카테고리 + → 그 카테고리 아래에 입력 줄(Enter 추가, Esc 닫기). + 아이콘은 45° 회전
- 진행 바 너비 transition .4s
- 테마 전환 시 레이아웃은 그대로, 토큰과 변형 컴포넌트만 교체

## State
- `theme`: `'base'|'matcha'|'cereal'|'iphone'|'dark'|'wish'|'space'`(localStorage)
- 달력 마크 상태는 날짜별 (할 일 수, 완료 수)에서 계산: 없음 / 0개 완료 / 일부 / 전부
- 아이폰: 남은 개수 → `heat` 단계. 우주: 완료율 → 달 모양, 날짜 → 실제 위상

## Assets
- `assets/tutu-sheet.png`: 시리얼 테마 캐릭터 시트(사용자 제공, 1536×1024, 흰 배경). 시안은 CSS `background-position`으로 마스코트 · 시리얼 링을 잘라 쓴다. **실제 구현 전에 마스코트 · 링을 배경 없는 PNG로 따로 받는 것을 권장**
- 프로필 사진: 사용자 업로드(시안에서는 빈 사진 칸)
- 아이콘과 장식(클로버, 나루토마끼, 리본, 날개, 해파리, 북두칠성)은 모두 CSS 도형이나 인라인 SVG로 그렸다. 소스에서 그대로 옮겨 쓰면 된다
- 웹폰트: Pretendard(jsDelivr), Google Fonts(Jua, Lilita One, Gaegu, Gowun Dodum, Noto Sans KR, Space Mono, Bricolage Grotesque), 미생체(noonnu jsDelivr)

## Files
- `테마 제안.dc.html`: 7개 테마 홈 화면 시안(값의 원본)
- `support.js`, `image-slot.js`: 시안 실행용(앱에는 필요 없음)
- `assets/tutu-sheet.png`: 시리얼 캐릭터
- `DESIGN.md`: 앱 측 부품 목록(현재 값)
- `screenshots/1a~1g-*.png`: 테마별 홈 화면 전체 캡처(1c · 1f는 1x, 나머지 2x). 캡처 도구 특성상 흐림 · 블렌드 효과가 실제 브라우저와 조금 다를 수 있으니, 정확한 모습은 HTML을 열어 확인

## 아직 시안이 없는 부분
홈 화면만 디자인했다. 플래너 · 타이머 · 개인정보 · 시트는 **같은 토큰**(카드, 버튼, 칩, 탭바, 링 색 = 대표색)을 적용하면 된다. 테마별 고유 부품(예: 타이머 링을 우주는 달 궤도로, 시리얼은 링 모양으로)은 추가 시안이 필요하다.
